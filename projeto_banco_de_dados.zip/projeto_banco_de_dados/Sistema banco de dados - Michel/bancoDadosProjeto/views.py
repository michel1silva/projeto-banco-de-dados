from flask import Blueprint, request, jsonify
import psycopg2
from bd import (
    # Filmes
    listar_filmes_db,
    criar_filme_db,
    editar_filme_db,
    deletar_filme_db,
    listar_atores_filme_db,
    # Avaliações
    listar_avaliacoes_filme_db,
    criar_avaliacao_db,
    editar_avaliacao_db,
    deletar_avaliacao_db,
    # Usuários
    listar_usuarios_db,
    criar_usuario_db,
    editar_usuario_db,
    deletar_usuario_db,
    # Atores
    listar_atores_db,
    criar_ator_db,
    editar_ator_db,
    deletar_ator_db,
    listar_filmes_ator_db,
    # Relações
    adicionar_ator_filme_db,
    remover_ator_filme_db
)

views = Blueprint("views", __name__)


def tratar_erro_banco(e):
    """Trata erros de conexão com o banco de dados"""
    if isinstance(e, psycopg2.OperationalError):
        return jsonify({
            "erro": "Não foi possível conectar ao banco de dados PostgreSQL",
            "detalhes": "Verifique se o PostgreSQL está rodando na porta 5432"
        }), 503
    return jsonify({"erro": str(e)}), 500


# ---------------------------------------------
# LISTAR FILMES
# ---------------------------------------------
@views.route("/filmes", methods=["GET"])
def listar_filmes():
    try:
        filmes = listar_filmes_db()
        return jsonify(filmes)
    except psycopg2.OperationalError as e:
        return tratar_erro_banco(e)
    except Exception as e:
        return jsonify({"erro": str(e)}), 500


# ---------------------------------------------
# LISTAR AVALIAÇÕES DE UM FILME
# ---------------------------------------------
@views.route("/filmes/<int:filme_id>/avaliacoes", methods=["GET"])
def listar_avaliacoes(filme_id):
    try:
        avaliacoes = listar_avaliacoes_filme_db(filme_id)
        return jsonify(avaliacoes)
    except psycopg2.OperationalError as e:
        return tratar_erro_banco(e)
    except Exception as e:
        return jsonify({"erro": str(e)}), 500


# ---------------------------------------------
# CRIAR USUÁRIO
# ---------------------------------------------
@views.route("/usuarios", methods=["POST"])
def criar_usuario():
    data = request.json
    nome = data["nome"]
    email = data["email"]
    senha_hash = data["senha"]

    user_id = criar_usuario_db(nome, email, senha_hash)

    return jsonify({"id": user_id, "mensagem": "Usuário criado"}), 201


# ---------------------------------------------
# CRIAR AVALIAÇÃO
# ---------------------------------------------
@views.route("/avaliacoes", methods=["POST"])
def criar_avaliacao():
    data = request.json

    avaliacao_id = criar_avaliacao_db(
        data["usuario_id"],
        data["filme_id"],
        data["nota"],
        data.get("comentario", "")
    )

    if avaliacao_id is None:
        return jsonify({"erro": "Usuário já avaliou este filme"}), 400

    return jsonify({"id": avaliacao_id, "mensagem": "Avaliação criada"}), 201


# ---------------------------------------------
# EDITAR AVALIAÇÃO
# ---------------------------------------------
@views.route("/avaliacoes/<int:avaliacao_id>", methods=["PUT"])
def editar_avaliacao(avaliacao_id):
    data = request.json
    editar_avaliacao_db(avaliacao_id, data["nota"], data["comentario"])
    return jsonify({"mensagem": "Avaliação atualizada"})


# ---------------------------------------------
# DELETAR AVALIAÇÃO
# ---------------------------------------------
@views.route("/avaliacoes/<int:avaliacao_id>", methods=["DELETE"])
def deletar_avaliacao(avaliacao_id):
    deletar_avaliacao_db(avaliacao_id)
    return jsonify({"mensagem": "Avaliação removida"})


# ---------------------------------------------
# USUÁRIOS
# ---------------------------------------------
@views.route("/usuarios", methods=["GET"])
def listar_usuarios():
    try:
        usuarios = listar_usuarios_db()
        return jsonify(usuarios)
    except psycopg2.OperationalError as e:
        return tratar_erro_banco(e)
    except Exception as e:
        return jsonify({"erro": str(e)}), 500


@views.route("/usuarios/<int:usuario_id>", methods=["PUT"])
def editar_usuario(usuario_id):
    try:
        data = request.json
        senha = data.get("senha")
        if senha and senha.strip() != "":
            editar_usuario_db(usuario_id, data["nome"], data["email"], senha)
        else:
            editar_usuario_db(usuario_id, data["nome"], data["email"], None)
        return jsonify({"mensagem": "Usuário atualizado"})
    except psycopg2.OperationalError as e:
        return tratar_erro_banco(e)
    except Exception as e:
        return jsonify({"erro": str(e)}), 500


@views.route("/usuarios/<int:usuario_id>", methods=["DELETE"])
def deletar_usuario(usuario_id):
    deletar_usuario_db(usuario_id)
    return jsonify({"mensagem": "Usuário removido"})


# ---------------------------------------------
# FILMES
# ---------------------------------------------
@views.route("/filmes", methods=["POST"])
def criar_filme():
    data = request.json
    ano = data.get("ano")
    genero = data.get("genero")
    
    # Converte strings vazias para None
    if ano == "" or ano is None:
        ano = None
    else:
        try:
            ano = int(ano)
        except (ValueError, TypeError):
            ano = None
    
    if genero == "" or genero is None:
        genero = None
    
    filme_id = criar_filme_db(
        data["titulo"],
        ano,
        genero
    )
    return jsonify({"id": filme_id, "mensagem": "Filme criado"}), 201


@views.route("/filmes/<int:filme_id>", methods=["PUT"])
def editar_filme(filme_id):
    data = request.json
    ano = data.get("ano")
    genero = data.get("genero")
    
    # Converte strings vazias para None
    if ano == "" or ano is None:
        ano = None
    else:
        try:
            ano = int(ano)
        except (ValueError, TypeError):
            ano = None
    
    if genero == "" or genero is None:
        genero = None
    
    editar_filme_db(
        filme_id,
        data["titulo"],
        ano,
        genero
    )
    return jsonify({"mensagem": "Filme atualizado"})


@views.route("/filmes/<int:filme_id>", methods=["DELETE"])
def deletar_filme(filme_id):
    deletar_filme_db(filme_id)
    return jsonify({"mensagem": "Filme removido"})


@views.route("/filmes/<int:filme_id>/atores", methods=["GET"])
def listar_atores_filme(filme_id):
    atores = listar_atores_filme_db(filme_id)
    return jsonify(atores)


# ---------------------------------------------
# ATORES
# ---------------------------------------------
@views.route("/atores", methods=["GET"])
def listar_atores():
    try:
        atores = listar_atores_db()
        return jsonify(atores)
    except psycopg2.OperationalError as e:
        return tratar_erro_banco(e)
    except Exception as e:
        return jsonify({"erro": str(e)}), 500


@views.route("/atores", methods=["POST"])
def criar_ator():
    data = request.json
    ator_id = criar_ator_db(data["nome"])
    return jsonify({"id": ator_id, "mensagem": "Ator criado"}), 201


@views.route("/atores/<int:ator_id>", methods=["PUT"])
def editar_ator(ator_id):
    data = request.json
    editar_ator_db(ator_id, data["nome"])
    return jsonify({"mensagem": "Ator atualizado"})


@views.route("/atores/<int:ator_id>", methods=["DELETE"])
def deletar_ator(ator_id):
    deletar_ator_db(ator_id)
    return jsonify({"mensagem": "Ator removido"})


@views.route("/atores/<int:ator_id>/filmes", methods=["GET"])
def listar_filmes_ator(ator_id):
    filmes = listar_filmes_ator_db(ator_id)
    return jsonify(filmes)


# ---------------------------------------------
# RELAÇÃO ATORES-FILMES
# ---------------------------------------------
@views.route("/filmes/<int:filme_id>/atores/<int:ator_id>", methods=["POST"])
def adicionar_ator_filme(filme_id, ator_id):
    sucesso = adicionar_ator_filme_db(ator_id, filme_id)
    if sucesso:
        return jsonify({"mensagem": "Ator adicionado ao filme"}), 201
    return jsonify({"erro": "Relação já existe"}), 400


@views.route("/filmes/<int:filme_id>/atores/<int:ator_id>", methods=["DELETE"])
def remover_ator_filme(filme_id, ator_id):
    remover_ator_filme_db(ator_id, filme_id)
    return jsonify({"mensagem": "Ator removido do filme"})
