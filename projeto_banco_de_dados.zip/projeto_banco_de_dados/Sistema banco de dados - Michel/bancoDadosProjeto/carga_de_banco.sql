-- ============================================
-- CARGA DE DADOS INICIAL DO BANCO
-- ============================================

-- Limpar dados existentes (opcional - descomente se quiser limpar antes de inserir)
-- DELETE FROM avaliacoes;
-- DELETE FROM atores_filmes;
-- DELETE FROM atores;
-- DELETE FROM filmes;
-- DELETE FROM usuarios;

-- ============================================
-- USUÁRIOS
-- ============================================
INSERT INTO usuarios (nome, email, senha_hash) VALUES
('João Silva', 'joao.silva@email.com', 'hash123'),
('Maria Santos', 'maria.santos@email.com', 'hash456'),
('Pedro Oliveira', 'pedro.oliveira@email.com', 'hash789'),
('Ana Costa', 'ana.costa@email.com', 'hash101'),
('Carlos Souza', 'carlos.souza@email.com', 'hash202'),
('Julia Ferreira', 'julia.ferreira@email.com', 'hash303'),
('Lucas Almeida', 'lucas.almeida@email.com', 'hash404'),
('Fernanda Lima', 'fernanda.lima@email.com', 'hash505')
ON CONFLICT (email) DO NOTHING;

-- ============================================
-- FILMES
-- ============================================
INSERT INTO filmes (titulo, ano, genero) VALUES
('Matrix', 1999, 'Ficção Científica'),
('Interestelar', 2014, 'Ficção Científica'),
('O Poderoso Chefão', 1972, 'Drama'),
('Pulp Fiction', 1994, 'Crime'),
('A Origem', 2010, 'Ficção Científica'),
('Clube da Luta', 1999, 'Drama'),
('Forrest Gump', 1994, 'Drama'),
('O Senhor dos Anéis: A Sociedade do Anel', 2001, 'Fantasia'),
('Vingadores: Ultimato', 2019, 'Ação'),
('Parasita', 2019, 'Thriller'),
('Duna', 2021, 'Ficção Científica'),
('Top Gun: Maverick', 2022, 'Ação')
ON CONFLICT DO NOTHING;

-- ============================================
-- ATORES
-- ============================================
INSERT INTO atores (nome) VALUES
('Keanu Reeves'),
('Matthew McConaughey'),
('Marlon Brando'),
('John Travolta'),
('Leonardo DiCaprio'),
('Brad Pitt'),
('Tom Hanks'),
('Elijah Wood'),
('Robert Downey Jr.'),
('Song Kang-ho'),
('Timothée Chalamet'),
('Tom Cruise'),
('Carrie-Anne Moss'),
('Anne Hathaway'),
('Al Pacino'),
('Samuel L. Jackson'),
('Marion Cotillard'),
('Edward Norton'),
('Gary Sinise'),
('Ian McKellen'),
('Chris Evans'),
('Lee Sun-kyun'),
('Rebecca Ferguson'),
('Miles Teller')
ON CONFLICT DO NOTHING;

-- ============================================
-- RELAÇÃO ATORES-FILMES
-- ============================================
-- Matrix
INSERT INTO atores_filmes (ator_id, filme_id) VALUES
((SELECT id FROM atores WHERE nome = 'Keanu Reeves' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Matrix' LIMIT 1)),
((SELECT id FROM atores WHERE nome = 'Carrie-Anne Moss' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Matrix' LIMIT 1))
ON CONFLICT DO NOTHING;

-- Interestelar
INSERT INTO atores_filmes (ator_id, filme_id) VALUES
((SELECT id FROM atores WHERE nome = 'Matthew McConaughey' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Interestelar' LIMIT 1)),
((SELECT id FROM atores WHERE nome = 'Anne Hathaway' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Interestelar' LIMIT 1))
ON CONFLICT DO NOTHING;

-- O Poderoso Chefão
INSERT INTO atores_filmes (ator_id, filme_id) VALUES
((SELECT id FROM atores WHERE nome = 'Marlon Brando' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'O Poderoso Chefão' LIMIT 1)),
((SELECT id FROM atores WHERE nome = 'Al Pacino' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'O Poderoso Chefão' LIMIT 1))
ON CONFLICT DO NOTHING;

-- Pulp Fiction
INSERT INTO atores_filmes (ator_id, filme_id) VALUES
((SELECT id FROM atores WHERE nome = 'John Travolta' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Pulp Fiction' LIMIT 1)),
((SELECT id FROM atores WHERE nome = 'Samuel L. Jackson' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Pulp Fiction' LIMIT 1))
ON CONFLICT DO NOTHING;

-- A Origem
INSERT INTO atores_filmes (ator_id, filme_id) VALUES
((SELECT id FROM atores WHERE nome = 'Leonardo DiCaprio' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'A Origem' LIMIT 1)),
((SELECT id FROM atores WHERE nome = 'Marion Cotillard' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'A Origem' LIMIT 1))
ON CONFLICT DO NOTHING;

-- Clube da Luta
INSERT INTO atores_filmes (ator_id, filme_id) VALUES
((SELECT id FROM atores WHERE nome = 'Brad Pitt' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Clube da Luta' LIMIT 1)),
((SELECT id FROM atores WHERE nome = 'Edward Norton' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Clube da Luta' LIMIT 1))
ON CONFLICT DO NOTHING;

-- Forrest Gump
INSERT INTO atores_filmes (ator_id, filme_id) VALUES
((SELECT id FROM atores WHERE nome = 'Tom Hanks' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Forrest Gump' LIMIT 1)),
((SELECT id FROM atores WHERE nome = 'Gary Sinise' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Forrest Gump' LIMIT 1))
ON CONFLICT DO NOTHING;

-- O Senhor dos Anéis
INSERT INTO atores_filmes (ator_id, filme_id) VALUES
((SELECT id FROM atores WHERE nome = 'Elijah Wood' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'O Senhor dos Anéis: A Sociedade do Anel' LIMIT 1)),
((SELECT id FROM atores WHERE nome = 'Ian McKellen' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'O Senhor dos Anéis: A Sociedade do Anel' LIMIT 1))
ON CONFLICT DO NOTHING;

-- Vingadores: Ultimato
INSERT INTO atores_filmes (ator_id, filme_id) VALUES
((SELECT id FROM atores WHERE nome = 'Robert Downey Jr.' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Vingadores: Ultimato' LIMIT 1)),
((SELECT id FROM atores WHERE nome = 'Chris Evans' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Vingadores: Ultimato' LIMIT 1))
ON CONFLICT DO NOTHING;

-- Parasita
INSERT INTO atores_filmes (ator_id, filme_id) VALUES
((SELECT id FROM atores WHERE nome = 'Song Kang-ho' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Parasita' LIMIT 1)),
((SELECT id FROM atores WHERE nome = 'Lee Sun-kyun' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Parasita' LIMIT 1))
ON CONFLICT DO NOTHING;

-- Duna
INSERT INTO atores_filmes (ator_id, filme_id) VALUES
((SELECT id FROM atores WHERE nome = 'Timothée Chalamet' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Duna' LIMIT 1)),
((SELECT id FROM atores WHERE nome = 'Rebecca Ferguson' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Duna' LIMIT 1))
ON CONFLICT DO NOTHING;

-- Top Gun: Maverick
INSERT INTO atores_filmes (ator_id, filme_id) VALUES
((SELECT id FROM atores WHERE nome = 'Tom Cruise' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Top Gun: Maverick' LIMIT 1)),
((SELECT id FROM atores WHERE nome = 'Miles Teller' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Top Gun: Maverick' LIMIT 1))
ON CONFLICT DO NOTHING;

-- ============================================
-- AVALIAÇÕES
-- ============================================
-- Avaliações para Matrix
INSERT INTO avaliacoes (usuario_id, filme_id, nota, comentario) VALUES
((SELECT id FROM usuarios WHERE email = 'joao.silva@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Matrix' LIMIT 1), 9.5, 'Filme revolucionário! Efeitos especiais incríveis para a época.'),
((SELECT id FROM usuarios WHERE email = 'maria.santos@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Matrix' LIMIT 1), 10.0, 'Obra-prima da ficção científica.'),
((SELECT id FROM usuarios WHERE email = 'pedro.oliveira@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Matrix' LIMIT 1), 8.5, 'Muito bom, mas alguns conceitos são complexos.')
ON CONFLICT (usuario_id, filme_id) DO NOTHING;

-- Avaliações para Interestelar
INSERT INTO avaliacoes (usuario_id, filme_id, nota, comentario) VALUES
((SELECT id FROM usuarios WHERE email = 'ana.costa@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Interestelar' LIMIT 1), 9.8, 'Emocionante e visualmente deslumbrante.'),
((SELECT id FROM usuarios WHERE email = 'carlos.souza@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Interestelar' LIMIT 1), 9.0, 'Excelente filme, mas um pouco longo.'),
((SELECT id FROM usuarios WHERE email = 'julia.ferreira@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Interestelar' LIMIT 1), 10.0, 'Perfeito! Uma experiência cinematográfica única.')
ON CONFLICT (usuario_id, filme_id) DO NOTHING;

-- Avaliações para O Poderoso Chefão
INSERT INTO avaliacoes (usuario_id, filme_id, nota, comentario) VALUES
((SELECT id FROM usuarios WHERE email = 'lucas.almeida@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'O Poderoso Chefão' LIMIT 1), 10.0, 'Clássico absoluto do cinema.'),
((SELECT id FROM usuarios WHERE email = 'fernanda.lima@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'O Poderoso Chefão' LIMIT 1), 9.5, 'Atuações impecáveis e roteiro perfeito.')
ON CONFLICT (usuario_id, filme_id) DO NOTHING;

-- Avaliações para Pulp Fiction
INSERT INTO avaliacoes (usuario_id, filme_id, nota, comentario) VALUES
((SELECT id FROM usuarios WHERE email = 'joao.silva@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Pulp Fiction' LIMIT 1), 9.0, 'Narrativa não linear genial.'),
((SELECT id FROM usuarios WHERE email = 'pedro.oliveira@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Pulp Fiction' LIMIT 1), 8.8, 'Muito criativo e bem dirigido.')
ON CONFLICT (usuario_id, filme_id) DO NOTHING;

-- Avaliações para A Origem
INSERT INTO avaliacoes (usuario_id, filme_id, nota, comentario) VALUES
((SELECT id FROM usuarios WHERE email = 'maria.santos@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'A Origem' LIMIT 1), 9.5, 'Mind-blowing! Precisa assistir várias vezes.'),
((SELECT id FROM usuarios WHERE email = 'carlos.souza@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'A Origem' LIMIT 1), 9.2, 'Conceito interessante e execução perfeita.')
ON CONFLICT (usuario_id, filme_id) DO NOTHING;

-- Avaliações para Clube da Luta
INSERT INTO avaliacoes (usuario_id, filme_id, nota, comentario) VALUES
((SELECT id FROM usuarios WHERE email = 'ana.costa@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Clube da Luta' LIMIT 1), 9.0, 'Filme cult com mensagem profunda.'),
((SELECT id FROM usuarios WHERE email = 'julia.ferreira@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Clube da Luta' LIMIT 1), 8.5, 'Bom filme, mas muito intenso.')
ON CONFLICT (usuario_id, filme_id) DO NOTHING;

-- Avaliações para Forrest Gump
INSERT INTO avaliacoes (usuario_id, filme_id, nota, comentario) VALUES
((SELECT id FROM usuarios WHERE email = 'lucas.almeida@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Forrest Gump' LIMIT 1), 9.8, 'Emocionante e inspirador.'),
((SELECT id FROM usuarios WHERE email = 'fernanda.lima@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Forrest Gump' LIMIT 1), 10.0, 'Tom Hanks está perfeito neste filme.')
ON CONFLICT (usuario_id, filme_id) DO NOTHING;

-- Avaliações para O Senhor dos Anéis
INSERT INTO avaliacoes (usuario_id, filme_id, nota, comentario) VALUES
((SELECT id FROM usuarios WHERE email = 'joao.silva@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'O Senhor dos Anéis: A Sociedade do Anel' LIMIT 1), 9.5, 'Adaptação perfeita do livro.'),
((SELECT id FROM usuarios WHERE email = 'maria.santos@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'O Senhor dos Anéis: A Sociedade do Anel' LIMIT 1), 10.0, 'Fantasia épica no seu melhor.')
ON CONFLICT (usuario_id, filme_id) DO NOTHING;

-- Avaliações para Vingadores: Ultimato
INSERT INTO avaliacoes (usuario_id, filme_id, nota, comentario) VALUES
((SELECT id FROM usuarios WHERE email = 'pedro.oliveira@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Vingadores: Ultimato' LIMIT 1), 9.0, 'Final épico para a saga.'),
((SELECT id FROM usuarios WHERE email = 'ana.costa@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Vingadores: Ultimato' LIMIT 1), 8.5, 'Muito bom, mas esperava mais.')
ON CONFLICT (usuario_id, filme_id) DO NOTHING;

-- Avaliações para Parasita
INSERT INTO avaliacoes (usuario_id, filme_id, nota, comentario) VALUES
((SELECT id FROM usuarios WHERE email = 'carlos.souza@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Parasita' LIMIT 1), 9.5, 'Thriller social brilhante.'),
((SELECT id FROM usuarios WHERE email = 'julia.ferreira@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Parasita' LIMIT 1), 10.0, 'Oscar merecido! Filme incrível.')
ON CONFLICT (usuario_id, filme_id) DO NOTHING;

-- Avaliações para Duna
INSERT INTO avaliacoes (usuario_id, filme_id, nota, comentario) VALUES
((SELECT id FROM usuarios WHERE email = 'lucas.almeida@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Duna' LIMIT 1), 9.0, 'Visualmente impressionante.'),
((SELECT id FROM usuarios WHERE email = 'fernanda.lima@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Duna' LIMIT 1), 8.8, 'Boa adaptação, mas incompleto.')
ON CONFLICT (usuario_id, filme_id) DO NOTHING;

-- Avaliações para Top Gun: Maverick
INSERT INTO avaliacoes (usuario_id, filme_id, nota, comentario) VALUES
((SELECT id FROM usuarios WHERE email = 'joao.silva@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Top Gun: Maverick' LIMIT 1), 9.5, 'Sequência melhor que o original!'),
((SELECT id FROM usuarios WHERE email = 'maria.santos@email.com' LIMIT 1), (SELECT id FROM filmes WHERE titulo = 'Top Gun: Maverick' LIMIT 1), 9.0, 'Ação de primeira qualidade.')
ON CONFLICT (usuario_id, filme_id) DO NOTHING;

-- ============================================
-- FIM DA CARGA DE DADOS
-- ============================================

