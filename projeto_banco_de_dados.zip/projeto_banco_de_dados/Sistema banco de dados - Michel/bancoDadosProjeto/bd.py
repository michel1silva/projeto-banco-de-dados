import psycopg2
from psycopg2.extras import RealDictCursor

def get_connection():
    return psycopg2.connect(
        host="localhost",
        database="bancofilme",
        port=5432,
        user="postgres",
        password="4569"
    )


# ----------------------------
# Funções do banco de dados
# ----------------------------

def listar_filmes_db():
    conn = get_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute("SELECT * FROM filmes ORDER BY id")
    filmes = cur.fetchall()
    cur.close()
    conn.close()
    return filmes


def listar_avaliacoes_filme_db(filme_id):
    conn = get_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)

    cur.execute("""
        SELECT a.id, a.nota, a.comentario, a.data_avaliacao, u.nome AS usuario
        FROM avaliacoes a
        JOIN usuarios u ON u.id = a.usuario_id
        WHERE a.filme_id = %s
        ORDER BY a.data_avaliacao DESC
    """, (filme_id,))

    avaliacoes = cur.fetchall()
    cur.close()
    conn.close()
    return avaliacoes


def criar_usuario_db(nome, email, senha_hash):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO usuarios (nome, email, senha_hash)
        VALUES (%s, %s, %s)
        RETURNING id
    """, (nome, email, senha_hash))

    user_id = cur.fetchone()[0]
    conn.commit()
    cur.close()
    conn.close()
    return user_id


def criar_avaliacao_db(usuario_id, filme_id, nota, comentario):
    conn = get_connection()
    cur = conn.cursor()

    try:
        cur.execute("""
            INSERT INTO avaliacoes (usuario_id, filme_id, nota, comentario)
            VALUES (%s, %s, %s, %s)
            RETURNING id
        """, (usuario_id, filme_id, nota, comentario))

        avaliacao_id = cur.fetchone()[0]
        conn.commit()

    except psycopg2.errors.UniqueViolation:
        conn.rollback()
        cur.close()
        conn.close()
        return None  # já existe avaliação

    cur.close()
    conn.close()
    return avaliacao_id


def editar_avaliacao_db(avaliacao_id, nota, comentario):
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        UPDATE avaliacoes
        SET nota = %s, comentario = %s
        WHERE id = %s
    """, (nota, comentario, avaliacao_id))

    conn.commit()
    cur.close()
    conn.close()


def deletar_avaliacao_db(avaliacao_id):
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("DELETE FROM avaliacoes WHERE id = %s", (avaliacao_id,))
    conn.commit()

    cur.close()
    conn.close()


# ----------------------------
# Funções para Usuários
# ----------------------------

def listar_usuarios_db():
    conn = get_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute("SELECT id, nome, email, data_criacao FROM usuarios ORDER BY id")
    usuarios = cur.fetchall()
    cur.close()
    conn.close()
    return usuarios


def editar_usuario_db(usuario_id, nome, email, senha_hash=None):
    conn = get_connection()
    cur = conn.cursor()
    if senha_hash:
        cur.execute("""
            UPDATE usuarios
            SET nome = %s, email = %s, senha_hash = %s
            WHERE id = %s
        """, (nome, email, senha_hash, usuario_id))
    else:
        cur.execute("""
            UPDATE usuarios
            SET nome = %s, email = %s
            WHERE id = %s
        """, (nome, email, usuario_id))
    conn.commit()
    cur.close()
    conn.close()


def deletar_usuario_db(usuario_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM usuarios WHERE id = %s", (usuario_id,))
    conn.commit()
    cur.close()
    conn.close()


# ----------------------------
# Funções para Filmes
# ----------------------------

def criar_filme_db(titulo, ano, genero):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO filmes (titulo, ano, genero)
        VALUES (%s, %s, %s)
        RETURNING id
    """, (titulo, ano, genero))
    filme_id = cur.fetchone()[0]
    conn.commit()
    cur.close()
    conn.close()
    return filme_id


def editar_filme_db(filme_id, titulo, ano, genero):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        UPDATE filmes
        SET titulo = %s, ano = %s, genero = %s
        WHERE id = %s
    """, (titulo, ano, genero, filme_id))
    conn.commit()
    cur.close()
    conn.close()


def deletar_filme_db(filme_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM filmes WHERE id = %s", (filme_id,))
    conn.commit()
    cur.close()
    conn.close()


def listar_atores_filme_db(filme_id):
    conn = get_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute("""
        SELECT a.id, a.nome
        FROM atores a
        JOIN atores_filmes af ON a.id = af.ator_id
        WHERE af.filme_id = %s
        ORDER BY a.nome
    """, (filme_id,))
    atores = cur.fetchall()
    cur.close()
    conn.close()
    return atores


# ----------------------------
# Funções para Atores
# ----------------------------

def listar_atores_db():
    conn = get_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute("SELECT * FROM atores ORDER BY nome")
    atores = cur.fetchall()
    cur.close()
    conn.close()
    return atores


def criar_ator_db(nome):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO atores (nome)
        VALUES (%s)
        RETURNING id
    """, (nome,))
    ator_id = cur.fetchone()[0]
    conn.commit()
    cur.close()
    conn.close()
    return ator_id


def editar_ator_db(ator_id, nome):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        UPDATE atores
        SET nome = %s
        WHERE id = %s
    """, (nome, ator_id))
    conn.commit()
    cur.close()
    conn.close()


def deletar_ator_db(ator_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM atores WHERE id = %s", (ator_id,))
    conn.commit()
    cur.close()
    conn.close()


def listar_filmes_ator_db(ator_id):
    conn = get_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute("""
        SELECT f.id, f.titulo, f.ano, f.genero
        FROM filmes f
        JOIN atores_filmes af ON f.id = af.filme_id
        WHERE af.ator_id = %s
        ORDER BY f.titulo
    """, (ator_id,))
    filmes = cur.fetchall()
    cur.close()
    conn.close()
    return filmes


# ----------------------------
# Funções para Relação Atores-Filmes
# ----------------------------

def adicionar_ator_filme_db(ator_id, filme_id):
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute("""
            INSERT INTO atores_filmes (ator_id, filme_id)
            VALUES (%s, %s)
        """, (ator_id, filme_id))
        conn.commit()
        cur.close()
        conn.close()
        return True
    except psycopg2.errors.UniqueViolation:
        conn.rollback()
        cur.close()
        conn.close()
        return False  # relação já existe


def remover_ator_filme_db(ator_id, filme_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        DELETE FROM atores_filmes
        WHERE ator_id = %s AND filme_id = %s
    """, (ator_id, filme_id))
    conn.commit()
    cur.close()
    conn.close()