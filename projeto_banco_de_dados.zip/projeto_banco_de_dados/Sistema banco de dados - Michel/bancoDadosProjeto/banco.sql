-- Tabela de Usuários
CREATE TABLE usuarios (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(200) UNIQUE NOT NULL,
    senha_hash TEXT NOT NULL,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Filmes
CREATE TABLE filmes (
    id SERIAL PRIMARY KEY,
    titulo VARCHAR(200) NOT NULL,
    ano INTEGER CHECK (ano > 1880 AND ano <= EXTRACT(YEAR FROM CURRENT_DATE) + 10),
    genero VARCHAR(100),
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Atores
CREATE TABLE atores (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(200) NOT NULL,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Relação Atores-Filmes (Muitos para Muitos)
CREATE TABLE atores_filmes (
    ator_id INT REFERENCES atores(id) ON DELETE CASCADE,
    filme_id INT REFERENCES filmes(id) ON DELETE CASCADE,
    PRIMARY KEY (ator_id, filme_id)
);

-- Tabela de Avaliações
CREATE TABLE avaliacoes (
    id SERIAL PRIMARY KEY,
    usuario_id INT REFERENCES usuarios(id) ON DELETE CASCADE,
    filme_id INT REFERENCES filmes(id) ON DELETE CASCADE,
    nota NUMERIC(3,1) CHECK (nota BETWEEN 0 AND 10),
    comentario TEXT,
    data_avaliacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (usuario_id, filme_id)  -- cada usuário avalia 1 vez por filme
);

-- Índices para melhorar performance
CREATE INDEX idx_filmes_titulo ON filmes(titulo);
CREATE INDEX idx_filmes_ano ON filmes(ano);
CREATE INDEX idx_avaliacoes_filme ON avaliacoes(filme_id);
CREATE INDEX idx_avaliacoes_usuario ON avaliacoes(usuario_id);
CREATE INDEX idx_atores_filmes_filme ON atores_filmes(filme_id);
CREATE INDEX idx_atores_filmes_ator ON atores_filmes(ator_id);

INSERT INTO usuarios (nome, email, senha_hash)
VALUES
('João', 'joao@email.com', 'hash123'),
('Maria', 'maria@email.com', 'hash456');

INSERT INTO filmes (titulo, ano, genero)
VALUES
('Matrix', 1999, 'Ficção'),
('Interestelar', 2014, 'Sci-Fi');

INSERT INTO atores (nome)
VALUES
('Keanu Reeves'),
('Matthew McConaughey');

INSERT INTO atores_filmes (ator_id, filme_id)
VALUES
(1,1),
(2,2);
