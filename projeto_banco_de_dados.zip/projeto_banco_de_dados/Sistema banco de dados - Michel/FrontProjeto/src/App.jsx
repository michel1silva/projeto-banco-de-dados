import { useState, useEffect } from 'react'

const API_URL = 'http://localhost:5001'

function App() {
  const [abaAtiva, setAbaAtiva] = useState('filmes')
  const [mensagem, setMensagem] = useState('')

  // Estados para Filmes
  const [filmes, setFilmes] = useState([])
  const [filmeEditando, setFilmeEditando] = useState(null)
  const [formFilme, setFormFilme] = useState({ titulo: '', ano: '', genero: '' })

  // Estados para Atores
  const [atores, setAtores] = useState([])
  const [atorEditando, setAtorEditando] = useState(null)
  const [formAtor, setFormAtor] = useState({ nome: '' })

  // Estados para Usuários
  const [usuarios, setUsuarios] = useState([])
  const [usuarioEditando, setUsuarioEditando] = useState(null)
  const [formUsuario, setFormUsuario] = useState({ nome: '', email: '', senha: '' })

  // Estados para Avaliações
  const [avaliacoes, setAvaliacoes] = useState([])
  const [avaliacaoEditando, setAvaliacaoEditando] = useState(null)
  const [formAvaliacao, setFormAvaliacao] = useState({ usuario_id: '', nota: '', comentario: '' })
  const [filmeSelecionado, setFilmeSelecionado] = useState(null)
  const [atoresFilme, setAtoresFilme] = useState([])
  const [atoresFilmeTemp, setAtoresFilmeTemp] = useState([]) // Estado temporário para edição
  const [mostrarAtoresFilme, setMostrarAtoresFilme] = useState(false)
  const [mostrarFormAvaliacao, setMostrarFormAvaliacao] = useState(false)
  const [mostrarSeletorAno, setMostrarSeletorAno] = useState(false)
  const [mostrarSeletorUsuario, setMostrarSeletorUsuario] = useState(false)
  const [pesquisaUsuario, setPesquisaUsuario] = useState('')
  
  // Estado para modal de confirmação
  const [modalConfirmacao, setModalConfirmacao] = useState({
    mostrar: false,
    titulo: '',
    mensagem: '',
    onConfirmar: null
  })

  useEffect(() => {
    if (abaAtiva === 'filmes') carregarFilmes()
    if (abaAtiva === 'atores') carregarAtores()
    if (abaAtiva === 'usuarios') carregarUsuarios()
  }, [abaAtiva])

  // Fechar seletor de ano ao clicar fora
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (mostrarSeletorAno && !event.target.closest('.ano-selector-container')) {
        setMostrarSeletorAno(false)
      }
      if (mostrarSeletorUsuario && !event.target.closest('.usuario-selector-container')) {
        setMostrarSeletorUsuario(false)
        setPesquisaUsuario('')
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [mostrarSeletorAno, mostrarSeletorUsuario])

  const mostrarMensagem = (texto, tipo = 'sucesso') => {
    setMensagem(texto)
    setTimeout(() => setMensagem(''), 3000)
  }

  const confirmarDelecao = (titulo, mensagem, onConfirmar) => {
    setModalConfirmacao({
      mostrar: true,
      titulo,
      mensagem,
      onConfirmar
    })
  }

  const fecharModalConfirmacao = () => {
    setModalConfirmacao({
      mostrar: false,
      titulo: '',
      mensagem: '',
      onConfirmar: null
    })
  }

  const executarConfirmacao = () => {
    if (modalConfirmacao.onConfirmar) {
      modalConfirmacao.onConfirmar()
    }
    fecharModalConfirmacao()
  }

  // Gerar lista de anos (de 1880 até o ano atual + 10)
  const gerarAnos = () => {
    const anoAtual = new Date().getFullYear()
    const anos = []
    for (let ano = 1880; ano <= anoAtual + 10; ano++) {
      anos.push(ano)
    }
    return anos.reverse() // Mais recentes primeiro
  }

  const selecionarAno = (ano) => {
    setFormFilme({ ...formFilme, ano: ano.toString() })
    setMostrarSeletorAno(false)
  }


  const selecionarUsuario = (usuario) => {
    setFormAvaliacao({ ...formAvaliacao, usuario_id: usuario.id.toString() })
    setMostrarSeletorUsuario(false)
    setPesquisaUsuario('')
  }

  // Filtrar usuários baseado na pesquisa (inclui o nome do usuário selecionado se houver)
  const usuariosFiltradosParaPesquisa = formAvaliacao.usuario_id 
    ? usuarios.filter(u => u.id.toString() === formAvaliacao.usuario_id)
    : usuarios.filter(usuario => 
        usuario.nome.toLowerCase().includes(pesquisaUsuario.toLowerCase()) ||
        usuario.email.toLowerCase().includes(pesquisaUsuario.toLowerCase()) ||
        usuario.id.toString().includes(pesquisaUsuario)
      )

  const obterNomeUsuario = () => {
    const usuario = usuarios.find(u => u.id.toString() === formAvaliacao.usuario_id)
    return usuario ? `${usuario.nome} (${usuario.email})` : ''
  }

  // ========== FILMES ==========
  const carregarFilmes = async () => {
    try {
      const res = await fetch(`${API_URL}/filmes`)
      const data = await res.json()
      if (res.status === 503 || data.erro) {
        mostrarMensagem(data.erro || 'Erro ao conectar ao banco de dados', 'erro')
        return
      }
      setFilmes(data)
    } catch (error) {
      mostrarMensagem('Erro ao carregar filmes. Verifique se o servidor está rodando.', 'erro')
    }
  }

  const salvarFilme = async (e) => {
    e.preventDefault()
    try {
      const url = filmeEditando ? `${API_URL}/filmes/${filmeEditando.id}` : `${API_URL}/filmes`
      const method = filmeEditando ? 'PUT' : 'POST'
      
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          titulo: formFilme.titulo,
          ano: formFilme.ano && formFilme.ano.toString().trim() !== '' ? parseInt(formFilme.ano) : null,
          genero: formFilme.genero && formFilme.genero.trim() !== '' ? formFilme.genero.trim() : null
        })
      })

      if (res.ok) {
        mostrarMensagem(filmeEditando ? 'Filme atualizado!' : 'Filme criado!')
        setFormFilme({ titulo: '', ano: '', genero: '' })
        setFilmeEditando(null)
        setMostrarSeletorAno(false)
        carregarFilmes()
      }
    } catch (error) {
      mostrarMensagem('Erro ao salvar filme', 'erro')
    }
  }

  const deletarFilme = async (id) => {
    const filme = filmes.find(f => f.id === id)
    confirmarDelecao(
      'Confirmar Exclusão',
      `Tem certeza que deseja deletar o filme "${filme?.titulo || 'este filme'}"? Esta ação não pode ser desfeita.`,
      async () => {
        try {
          const res = await fetch(`${API_URL}/filmes/${id}`, { method: 'DELETE' })
          if (res.ok) {
            mostrarMensagem('Filme deletado!')
            carregarFilmes()
          }
        } catch (error) {
          mostrarMensagem('Erro ao deletar', 'erro')
        }
      }
    )
  }

  const editarFilme = (filme) => {
    setFilmeEditando(filme)
    setFormFilme({ titulo: filme.titulo, ano: filme.ano || '', genero: filme.genero || '' })
  }

  const carregarAtoresFilme = async (filmeId) => {
    try {
      const res = await fetch(`${API_URL}/filmes/${filmeId}/atores`)
      const data = await res.json()
      setAtoresFilme(data)
      setAtoresFilmeTemp(data) // Inicializa o estado temporário
    } catch (error) {
      mostrarMensagem('Erro ao carregar atores', 'erro')
    }
  }

  const adicionarAtorFilmeTemp = (atorId) => {
    const ator = atores.find(a => a.id === atorId)
    if (ator && !atoresFilmeTemp.find(af => af.id === ator.id)) {
      setAtoresFilmeTemp([...atoresFilmeTemp, ator])
    }
  }

  const removerAtorFilmeTemp = (atorId) => {
    setAtoresFilmeTemp(atoresFilmeTemp.filter(af => af.id !== atorId))
  }

  const salvarAtoresFilme = async () => {
    if (!filmeSelecionado) return

    try {
      // Remover todos os atores atuais
      for (const ator of atoresFilme) {
        try {
          await fetch(`${API_URL}/filmes/${filmeSelecionado}/atores/${ator.id}`, { method: 'DELETE' })
        } catch (error) {
          // Ignora erros ao remover
        }
      }

      // Adicionar os atores do estado temporário
      for (const ator of atoresFilmeTemp) {
        try {
          const res = await fetch(`${API_URL}/filmes/${filmeSelecionado}/atores/${ator.id}`, { method: 'POST' })
          if (!res.ok && res.status !== 400) {
            throw new Error('Erro ao adicionar ator')
          }
        } catch (error) {
          // Ignora erros se o ator já estiver no filme
        }
      }

      mostrarMensagem('Atores salvos com sucesso!')
      await carregarAtoresFilme(filmeSelecionado)
      setMostrarAtoresFilme(false)
      setFilmeSelecionado(null)
    } catch (error) {
      mostrarMensagem('Erro ao salvar atores', 'erro')
    }
  }

  // ========== ATORES ==========
  const carregarAtores = async () => {
    try {
      const res = await fetch(`${API_URL}/atores`)
      const data = await res.json()
      if (res.status === 503 || data.erro) {
        mostrarMensagem(data.erro || 'Erro ao conectar ao banco de dados', 'erro')
        return
      }
      setAtores(data)
    } catch (error) {
      mostrarMensagem('Erro ao carregar atores. Verifique se o servidor está rodando.', 'erro')
    }
  }

  const salvarAtor = async (e) => {
    e.preventDefault()
    try {
      const url = atorEditando ? `${API_URL}/atores/${atorEditando.id}` : `${API_URL}/atores`
      const method = atorEditando ? 'PUT' : 'POST'
      
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nome: formAtor.nome })
      })

      if (res.ok) {
        mostrarMensagem(atorEditando ? 'Ator atualizado!' : 'Ator criado!')
        setFormAtor({ nome: '' })
        setAtorEditando(null)
        carregarAtores()
      }
    } catch (error) {
      mostrarMensagem('Erro ao salvar ator', 'erro')
    }
  }

  const deletarAtor = async (id) => {
    const ator = atores.find(a => a.id === id)
    confirmarDelecao(
      'Confirmar Exclusão',
      `Tem certeza que deseja deletar o ator "${ator?.nome || 'este ator'}"? Esta ação não pode ser desfeita.`,
      async () => {
        try {
          const res = await fetch(`${API_URL}/atores/${id}`, { method: 'DELETE' })
          if (res.ok) {
            mostrarMensagem('Ator deletado!')
            carregarAtores()
          }
        } catch (error) {
          mostrarMensagem('Erro ao deletar', 'erro')
        }
      }
    )
  }

  const editarAtor = (ator) => {
    setAtorEditando(ator)
    setFormAtor({ nome: ator.nome })
  }

  // ========== USUÁRIOS ==========
  const carregarUsuarios = async () => {
    try {
      const res = await fetch(`${API_URL}/usuarios`)
      const data = await res.json()
      if (res.status === 503 || data.erro) {
        mostrarMensagem(data.erro || 'Erro ao conectar ao banco de dados', 'erro')
        return
      }
      setUsuarios(data)
    } catch (error) {
      mostrarMensagem('Erro ao carregar usuários. Verifique se o servidor está rodando.', 'erro')
    }
  }

  const salvarUsuario = async (e) => {
    e.preventDefault()
    try {
      if (usuarioEditando) {
        const body = { nome: formUsuario.nome, email: formUsuario.email }
        // Adiciona senha apenas se foi preenchida
        if (formUsuario.senha && formUsuario.senha.trim() !== '') {
          body.senha = formUsuario.senha
        }
        const res = await fetch(`${API_URL}/usuarios/${usuarioEditando.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body)
        })
        if (res.ok) {
          mostrarMensagem('Usuário atualizado!')
          setFormUsuario({ nome: '', email: '', senha: '' })
          setUsuarioEditando(null)
          carregarUsuarios()
        }
      } else {
        const res = await fetch(`${API_URL}/usuarios`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formUsuario)
        })
        if (res.ok) {
          mostrarMensagem('Usuário criado!')
          setFormUsuario({ nome: '', email: '', senha: '' })
          carregarUsuarios()
        }
      }
    } catch (error) {
      mostrarMensagem('Erro ao salvar usuário', 'erro')
    }
  }

  const deletarUsuario = async (id) => {
    const usuario = usuarios.find(u => u.id === id)
    confirmarDelecao(
      'Confirmar Exclusão',
      `Tem certeza que deseja deletar o usuário "${usuario?.nome || 'este usuário'}"? Esta ação não pode ser desfeita.`,
      async () => {
        try {
          const res = await fetch(`${API_URL}/usuarios/${id}`, { method: 'DELETE' })
          if (res.ok) {
            mostrarMensagem('Usuário deletado!')
            carregarUsuarios()
          }
        } catch (error) {
          mostrarMensagem('Erro ao deletar', 'erro')
        }
      }
    )
  }

  const editarUsuario = (usuario) => {
    setUsuarioEditando(usuario)
    setFormUsuario({ nome: usuario.nome, email: usuario.email, senha: '' })
  }

  // ========== AVALIAÇÕES ==========
  const carregarAvaliacoes = async (filmeId) => {
    try {
      const res = await fetch(`${API_URL}/filmes/${filmeId}/avaliacoes`)
      const data = await res.json()
      setAvaliacoes(data)
    } catch (error) {
      mostrarMensagem('Erro ao carregar avaliações', 'erro')
    }
  }

  const salvarAvaliacao = async (e) => {
    e.preventDefault()
    try {
      const url = avaliacaoEditando 
        ? `${API_URL}/avaliacoes/${avaliacaoEditando.id}`
        : `${API_URL}/avaliacoes`
      
      const method = avaliacaoEditando ? 'PUT' : 'POST'
      const body = avaliacaoEditando
        ? { nota: formAvaliacao.nota, comentario: formAvaliacao.comentario }
        : { ...formAvaliacao, filme_id: filmeSelecionado }

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      })

      if (res.ok) {
        mostrarMensagem(avaliacaoEditando ? 'Avaliação atualizada!' : 'Avaliação criada!')
        setFormAvaliacao({ usuario_id: '', nota: '', comentario: '' })
        setAvaliacaoEditando(null)
        setMostrarFormAvaliacao(false)
        if (filmeSelecionado) carregarAvaliacoes(filmeSelecionado)
      } else {
        const data = await res.json()
        mostrarMensagem(data.erro || 'Erro ao salvar avaliação', 'erro')
      }
    } catch (error) {
      mostrarMensagem('Erro ao salvar avaliação', 'erro')
    }
  }

  const deletarAvaliacao = async (id) => {
    const avaliacao = avaliacoes.find(a => a.id === id)
    confirmarDelecao(
      'Confirmar Exclusão',
      `Tem certeza que deseja deletar a avaliação de "${avaliacao?.usuario || 'este usuário'}"? Esta ação não pode ser desfeita.`,
      async () => {
        try {
          const res = await fetch(`${API_URL}/avaliacoes/${id}`, { method: 'DELETE' })
          if (res.ok) {
            mostrarMensagem('Avaliação deletada!')
            if (filmeSelecionado) carregarAvaliacoes(filmeSelecionado)
          }
        } catch (error) {
          mostrarMensagem('Erro ao deletar', 'erro')
        }
      }
    )
  }

  const abrirAvaliacoes = async (filmeId) => {
    setFilmeSelecionado(filmeId)
    setMostrarAtoresFilme(false)
    await carregarAvaliacoes(filmeId)
  }

  const editarAvaliacao = (av) => {
    setAvaliacaoEditando(av)
    setFormAvaliacao({ usuario_id: '', nota: av.nota, comentario: av.comentario || '' })
  }

  return (
    <div className="container">
      <h1>🎬 Sistema de Gerenciamento de Filmes</h1>

      {mensagem && (
        <div className={mensagem.includes('Erro') ? 'error' : 'success'}>
          {mensagem}
        </div>
      )}

      <div className="tabs">
        <button 
          className={abaAtiva === 'filmes' ? 'tab active' : 'tab'}
          onClick={() => setAbaAtiva('filmes')}
        >
          Filmes
        </button>
        <button 
          className={abaAtiva === 'atores' ? 'tab active' : 'tab'}
          onClick={() => setAbaAtiva('atores')}
        >
          Atores
        </button>
        <button 
          className={abaAtiva === 'usuarios' ? 'tab active' : 'tab'}
          onClick={() => setAbaAtiva('usuarios')}
        >
          Usuários
        </button>
        <button 
          className={abaAtiva === 'avaliacoes' ? 'tab active' : 'tab'}
          onClick={() => setAbaAtiva('avaliacoes')}
        >
          Avaliações
        </button>
      </div>

      {/* ABA FILMES */}
      {abaAtiva === 'filmes' && (
        <div className="aba-conteudo">
          <div className="form-section">
            <h2>{filmeEditando ? 'Editar Filme' : 'Novo Filme'}</h2>
            <form onSubmit={salvarFilme} className="form">
              <input
                type="text"
                placeholder="Título"
                value={formFilme.titulo}
                onChange={(e) => setFormFilme({ ...formFilme, titulo: e.target.value })}
                required
              />
              <div className="ano-selector-container">
                <input
                  type="text"
                  placeholder="Ano"
                  value={formFilme.ano}
                  readOnly
                  onClick={() => setMostrarSeletorAno(!mostrarSeletorAno)}
                  className="ano-input"
                />
                {mostrarSeletorAno && (
                  <div className="ano-selector-dropdown">
                    <div className="ano-selector-header">
                      <span>Selecione o Ano</span>
                      <button 
                        type="button"
                        className="ano-selector-close"
                        onClick={(e) => {
                          e.stopPropagation()
                          setMostrarSeletorAno(false)
                        }}
                      >
                        ×
                      </button>
                    </div>
                    <div className="ano-selector-list">
                      {gerarAnos().map(ano => (
                        <div
                          key={ano}
                          className={`ano-selector-item ${formFilme.ano === ano.toString() ? 'selected' : ''}`}
                          onClick={() => selecionarAno(ano)}
                        >
                          {ano}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              <input
                type="text"
                placeholder="Gênero"
                value={formFilme.genero}
                onChange={(e) => setFormFilme({ ...formFilme, genero: e.target.value })}
              />
              <div className="botoes">
                <button type="submit" className="btn">
                  {filmeEditando ? 'Salvar' : 'Criar'}
                </button>
                {filmeEditando && (
                  <button type="button" className="btn btn-secondary" onClick={() => {
                    setFilmeEditando(null)
                    setFormFilme({ titulo: '', ano: '', genero: '' })
                    setMostrarSeletorAno(false)
                  }}>
                    Cancelar
                  </button>
                )}
              </div>
            </form>
          </div>

          <h2>Lista de Filmes</h2>
          <div className="grid">
            {filmes.map(filme => (
              <div key={filme.id} className="card">
                <h3>{filme.titulo}</h3>
                <p>Ano: {filme.ano || '-'} | Gênero: {filme.genero || '-'}</p>
                <div className="botoes">
                  <button className="btn btn-small" onClick={() => {
                    editarFilme(filme)
                  }}>Editar</button>
                  <button className="btn btn-small" onClick={async () => {
                    setFilmeSelecionado(filme.id)
                    setMostrarAtoresFilme(true)
                    await carregarAtoresFilme(filme.id)
                  }}>Atores</button>
                  <button className="btn btn-small" onClick={() => abrirAvaliacoes(filme.id)}>
                    Avaliações
                  </button>
                  <button className="btn btn-small btn-danger" onClick={() => deletarFilme(filme.id)}>
                    Deletar
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ABA ATORES */}
      {abaAtiva === 'atores' && (
        <div className="aba-conteudo">
          <div className="form-section">
            <h2>{atorEditando ? 'Editar Ator' : 'Novo Ator'}</h2>
            <form onSubmit={salvarAtor} className="form">
              <input
                type="text"
                placeholder="Nome do Ator"
                value={formAtor.nome}
                onChange={(e) => setFormAtor({ nome: e.target.value })}
                required
              />
              <div className="botoes">
                <button type="submit" className="btn">
                  {atorEditando ? 'Salvar' : 'Criar'}
                </button>
                {atorEditando && (
                  <button type="button" className="btn btn-secondary" onClick={() => {
                    setAtorEditando(null)
                    setFormAtor({ nome: '' })
                  }}>
                    Cancelar
                  </button>
                )}
              </div>
            </form>
          </div>

          <h2>Lista de Atores</h2>
          <div className="grid">
            {atores.map(ator => (
              <div key={ator.id} className="card">
                <h3>{ator.nome}</h3>
                <div className="botoes">
                  <button className="btn btn-small" onClick={() => editarAtor(ator)}>
                    Editar
                  </button>
                  <button className="btn btn-small btn-danger" onClick={() => deletarAtor(ator.id)}>
                    Deletar
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ABA USUÁRIOS */}
      {abaAtiva === 'usuarios' && (
        <div className="aba-conteudo">
          <div className="form-section">
            <h2>{usuarioEditando ? 'Editar Usuário' : 'Novo Usuário'}</h2>
            <form onSubmit={salvarUsuario} className="form">
              <input
                type="text"
                placeholder="Nome"
                value={formUsuario.nome}
                onChange={(e) => setFormUsuario({ ...formUsuario, nome: e.target.value })}
                required
              />
              <input
                type="email"
                placeholder="Email"
                value={formUsuario.email}
                onChange={(e) => setFormUsuario({ ...formUsuario, email: e.target.value })}
                required
              />
              {!usuarioEditando ? (
                <input
                  type="password"
                  placeholder="Senha"
                  value={formUsuario.senha}
                  onChange={(e) => setFormUsuario({ ...formUsuario, senha: e.target.value })}
                  required
                />
              ) : (
                <input
                  type="password"
                  placeholder="Nova Senha (deixe em branco para manter a atual)"
                  value={formUsuario.senha}
                  onChange={(e) => setFormUsuario({ ...formUsuario, senha: e.target.value })}
                />
              )}
              <div className="botoes">
                <button type="submit" className="btn">
                  {usuarioEditando ? 'Salvar' : 'Criar'}
                </button>
                {usuarioEditando && (
                  <button type="button" className="btn btn-secondary" onClick={() => {
                    setUsuarioEditando(null)
                    setFormUsuario({ nome: '', email: '', senha: '' })
                  }}>
                    Cancelar
                  </button>
                )}
              </div>
            </form>
          </div>

          <h2>Lista de Usuários</h2>
          <div className="grid">
            {usuarios.map(usuario => (
              <div key={usuario.id} className="card">
                <h3>{usuario.nome}</h3>
                <p>Email: {usuario.email}</p>
                <div className="botoes">
                  <button className="btn btn-small" onClick={() => editarUsuario(usuario)}>
                    Editar
                  </button>
                  <button className="btn btn-small btn-danger" onClick={() => deletarUsuario(usuario.id)}>
                    Deletar
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ABA AVALIAÇÕES */}
      {abaAtiva === 'avaliacoes' && (
        <div className="aba-conteudo">
          <h2>Selecione um Filme para Ver Avaliações</h2>
          <div className="grid">
            {filmes.map(filme => (
              <div key={filme.id} className="card">
                <h3>{filme.titulo}</h3>
                <button className="btn" onClick={() => abrirAvaliacoes(filme.id)}>
                  Ver Avaliações
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MODAL DE AVALIAÇÕES */}
      {filmeSelecionado && !mostrarAtoresFilme && !mostrarFormAvaliacao && !avaliacaoEditando && (
        <div className="modal" onClick={() => {
          setFilmeSelecionado(null)
          setAvaliacoes([])
        }}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <button className="close-btn" onClick={() => {
              setFilmeSelecionado(null)
              setAvaliacoes([])
            }}>×</button>
            <h2>Avaliações - {filmes.find(f => f.id === filmeSelecionado)?.titulo}</h2>
            <button className="btn" onClick={() => {
              setAvaliacaoEditando(null)
              setFormAvaliacao({ usuario_id: '', nota: '', comentario: '' })
              setMostrarFormAvaliacao(true)
            }}>
              + Nova Avaliação
            </button>
            <div className="avaliacoes-list">
              {avaliacoes.length > 0 ? (
                avaliacoes.map(av => (
                  <div key={av.id} className="avaliacao-item">
                    <div className="avaliacao-header">
                      <strong>{av.usuario}</strong>
                      <span>⭐ {av.nota}/10</span>
                    </div>
                    {av.comentario && <p>{av.comentario}</p>}
                    <small>{new Date(av.data_avaliacao).toLocaleString('pt-BR')}</small>
                    <div className="botoes">
                      <button className="btn btn-small" onClick={() => editarAvaliacao(av)}>
                        Editar
                      </button>
                      <button className="btn btn-small btn-danger" onClick={() => deletarAvaliacao(av.id)}>
                        Deletar
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <p>Nenhuma avaliação ainda.</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* MODAL DE FORMULÁRIO DE AVALIAÇÃO */}
      {filmeSelecionado && !avaliacaoEditando && mostrarFormAvaliacao && (
        <div className="modal" onClick={() => {
          setMostrarFormAvaliacao(false)
          setFormAvaliacao({ usuario_id: '', nota: '', comentario: '' })
        }}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <button className="close-btn" onClick={() => {
              setMostrarFormAvaliacao(false)
              setFormAvaliacao({ usuario_id: '', nota: '', comentario: '' })
            }}>×</button>
            <h2>Nova Avaliação</h2>
            <form onSubmit={salvarAvaliacao} className="form">
              <div className="usuario-selector-container">
                <input
                  type="text"
                  placeholder="Selecione um usuário"
                  value={formAvaliacao.usuario_id ? obterNomeUsuario() : pesquisaUsuario}
                  onChange={(e) => {
                    setPesquisaUsuario(e.target.value)
                    if (!formAvaliacao.usuario_id) {
                      setMostrarSeletorUsuario(true)
                      if (!mostrarSeletorUsuario) {
                        carregarUsuarios()
                      }
                    }
                  }}
                  onFocus={() => {
                    if (!formAvaliacao.usuario_id) {
                      setMostrarSeletorUsuario(true)
                      carregarUsuarios()
                    }
                  }}
                  onClick={() => {
                    if (!formAvaliacao.usuario_id) {
                      setMostrarSeletorUsuario(true)
                      carregarUsuarios()
                    }
                  }}
                  className="usuario-input"
                  required
                />
                {formAvaliacao.usuario_id && (
                  <button
                    type="button"
                    className="usuario-clear"
                    onClick={(e) => {
                      e.stopPropagation()
                      setFormAvaliacao({ ...formAvaliacao, usuario_id: '' })
                      setPesquisaUsuario('')
                      setMostrarSeletorUsuario(false)
                    }}
                  >
                    ×
                  </button>
                )}
                {mostrarSeletorUsuario && (
                  <div className="usuario-selector-dropdown">
                    <div className="usuario-selector-list">
                      {usuariosFiltradosParaPesquisa.length > 0 ? (
                        usuariosFiltradosParaPesquisa.map(usuario => (
                          <div
                            key={usuario.id}
                            className={`usuario-selector-item ${formAvaliacao.usuario_id === usuario.id.toString() ? 'selected' : ''}`}
                            onClick={() => selecionarUsuario(usuario)}
                          >
                            <div>
                              <strong>{usuario.nome}</strong>
                              <small>{usuario.email}</small>
                            </div>
                            <span className="usuario-id">ID: {usuario.id}</span>
                          </div>
                        ))
                      ) : (
                        <div className="usuario-selector-empty">
                          Nenhum usuário encontrado
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
              <input
                type="text"
                placeholder="Nota (0-10)"
                value={formAvaliacao.nota}
                onChange={(e) => {
                  const valor = e.target.value.replace(/[^0-9.,]/g, '').replace(',', '.')
                  // Permite apenas números e um ponto decimal, máximo 10
                  if (valor === '' || (parseFloat(valor) >= 0 && parseFloat(valor) <= 10)) {
                    setFormAvaliacao({ ...formAvaliacao, nota: valor })
                  }
                }}
                onBlur={(e) => {
                  // Garante que o valor está entre 0 e 10
                  const valor = parseFloat(e.target.value)
                  if (isNaN(valor) || valor < 0) {
                    setFormAvaliacao({ ...formAvaliacao, nota: '' })
                  } else if (valor > 10) {
                    setFormAvaliacao({ ...formAvaliacao, nota: '10' })
                  }
                }}
                required
              />
              <textarea
                placeholder="Comentário (opcional)"
                value={formAvaliacao.comentario}
                onChange={(e) => setFormAvaliacao({ ...formAvaliacao, comentario: e.target.value })}
              />
              <button type="submit" className="btn">Criar</button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL DE EDITAR AVALIAÇÃO */}
      {avaliacaoEditando && (
        <div className="modal" onClick={() => setAvaliacaoEditando(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <button className="close-btn" onClick={() => setAvaliacaoEditando(null)}>×</button>
            <h2>Editar Avaliação</h2>
            <form onSubmit={salvarAvaliacao} className="form">
              <input
                type="text"
                placeholder="Nota (0-10)"
                value={formAvaliacao.nota}
                onChange={(e) => {
                  const valor = e.target.value.replace(/[^0-9.,]/g, '').replace(',', '.')
                  // Permite apenas números e um ponto decimal, máximo 10
                  if (valor === '' || (parseFloat(valor) >= 0 && parseFloat(valor) <= 10)) {
                    setFormAvaliacao({ ...formAvaliacao, nota: valor })
                  }
                }}
                onBlur={(e) => {
                  // Garante que o valor está entre 0 e 10
                  const valor = parseFloat(e.target.value)
                  if (isNaN(valor) || valor < 0) {
                    setFormAvaliacao({ ...formAvaliacao, nota: '' })
                  } else if (valor > 10) {
                    setFormAvaliacao({ ...formAvaliacao, nota: '10' })
                  }
                }}
                required
              />
              <textarea
                placeholder="Comentário (opcional)"
                value={formAvaliacao.comentario}
                onChange={(e) => setFormAvaliacao({ ...formAvaliacao, comentario: e.target.value })}
              />
              <button type="submit" className="btn">Salvar</button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL DE ATORES DO FILME */}
      {mostrarAtoresFilme && filmeSelecionado && (
        <div className="modal" onClick={() => {
          setMostrarAtoresFilme(false)
          setFilmeSelecionado(null)
          setAtoresFilme([])
        }}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <button className="close-btn" onClick={() => {
              setMostrarAtoresFilme(false)
              setFilmeSelecionado(null)
              setAtoresFilme([])
            }}>×</button>
            <h2>Atores - {filmes.find(f => f.id === filmeSelecionado)?.titulo}</h2>
            <div className="form-section">
              <h3>Adicionar Ator</h3>
              <select onChange={(e) => {
                if (e.target.value) {
                  adicionarAtorFilmeTemp(parseInt(e.target.value))
                  e.target.value = ''
                }
              }}>
                <option value="">Selecione um ator...</option>
                {atores.filter(a => !atoresFilmeTemp.find(af => af.id === a.id)).map(ator => (
                  <option key={ator.id} value={ator.id}>{ator.nome}</option>
                ))}
              </select>
            </div>
            <div className="avaliacoes-list">
              {atoresFilmeTemp.length > 0 ? (
                atoresFilmeTemp.map(ator => (
                  <div key={ator.id} className="avaliacao-item">
                    <strong>{ator.nome}</strong>
                    <button 
                      className="btn btn-small btn-danger"
                      onClick={() => removerAtorFilmeTemp(ator.id)}
                    >
                      Remover
                    </button>
                  </div>
                ))
              ) : (
                <p>Nenhum ator adicionado ainda.</p>
              )}
            </div>
            <div className="modal-confirmacao-botoes" style={{ marginTop: '20px' }}>
              <button 
                className="btn btn-secondary" 
                onClick={() => {
                  setMostrarAtoresFilme(false)
                  setFilmeSelecionado(null)
                  setAtoresFilme([])
                  setAtoresFilmeTemp([])
                }}
              >
                Cancelar
              </button>
              <button 
                className="btn" 
                onClick={salvarAtoresFilme}
              >
                Salvar Atores
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL DE CONFIRMAÇÃO DE DELEÇÃO */}
      {modalConfirmacao.mostrar && (
        <div className="modal modal-confirmacao" onClick={fecharModalConfirmacao}>
          <div className="modal-content modal-confirmacao-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-confirmacao-icon">⚠️</div>
            <h2 className="modal-confirmacao-titulo">{modalConfirmacao.titulo}</h2>
            <p className="modal-confirmacao-mensagem">{modalConfirmacao.mensagem}</p>
            <div className="modal-confirmacao-botoes">
              <button 
                className="btn btn-secondary" 
                onClick={fecharModalConfirmacao}
              >
                Cancelar
              </button>
              <button 
                className="btn btn-danger" 
                onClick={executarConfirmacao}
              >
                Deletar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default App
